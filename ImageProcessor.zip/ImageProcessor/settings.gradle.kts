rootProject.name = "ImageProcessor"

